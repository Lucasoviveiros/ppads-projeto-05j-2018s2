<html>
<head>
<link type="text/css" rel="stylesheet" href="styles/estiloGerenciar.css" />
</head>
<body>
<div id="geral">
<div id="tabela">
	<h2>REALIZAR DOA&Ccedil;&Atilde;O</h2>
    <ul>
        <li id="ativo"><a class="link" href="inserir.php" target="_self">INCLUIR DOACAO</a></li>
        <li><a class="link" href="" target="_self">ALTERAR LOCAL</a></li>
        <li><a class="link" href="" target="_self">MENU</a></li>
    </ul>
</div>
<form action="acoes/cadastrarDoador.php" method="post">
<table class="bordasimples">
	<thead><h3>FAZER DOA&Ccedil;&Atilde;O</h3></thead>
	<tr>
		<td>Nome doador: </td>
        <td><input type="text" name="nome_doador" placeholder="Afonso Padilha"/></td>
	</tr>
    <tr>
    	<td>Descri&ccedil;&atilde;o da doa&ccedil;&atilde;o: </td>
        <td><input type="text" name="descricao" placeholder="Cama, sofa, guarda-roupa"/></td>
    </tr>
    <tr>
    	<td>Qualidade da doa&ccedil;&atilde;o: </td>
        <td><input type="text" name="qualidade" placeholder="Semi novo, sem defeitos ou delaminacao"/></td>
    </tr>
    <tr>
    	<td>Quantidade: </td>
        <td><input type="text" name="quantidade" placeholder="2 sofas, 1 guarda-roupa"/></td>
    </tr>
	<tr>
    	<td>Endere&ccedil;o de retirada: </td>
        <td><input type="text" name="retirada" placeholder="Rua Dankmar Adler, 100"/></td>
    </tr>
    <tr>
    	<td>Endere&ccedil;o de entrega: </td>
        <td><input type="text" name="entrega" placeholder="Rua da Consolacao, 922"/></td>
    </tr>
</table>
<input type="submit" value="Cadastrar" id="submit"/>
</form>
</div>
</body>
</html>