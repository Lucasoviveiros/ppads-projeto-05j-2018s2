<html>
<head>
<link type="text/css" rel="stylesheet" href="styles/estiloGerenciar.css" />
</head>
<body>
<div id="geral">
<div id="tabela">
	<h2>CADASTRAR LOCAIS</h2>
    <ul>
        <li id="ativo"><a class="link" href="inserir.php" target="_self">INCLUIR LOCAL</a></li>
        <li><a class="link" href="" target="_self">ALTERAR LOCAL</a></li>
        <li><a class="link" href="" target="_self">MENU</a></li>
    </ul>
</div>
<form action="acoes/cadastrar.php" method="post">
<table class="bordasimples">
	<tr>
		<td>Endere&ccedil;o: </td>
        <td><input type="text" name="rua" placeholder="Rua da Consolacao, 922, Centro"/></td>
	</tr>
    <tr>
    	<td>Ponto de referencia: </td>
        <td><input type="text" name="ponto_referencia" placeholder="Proximo a praca Roosvelt"/></td>
    </tr>
    <tr>
    	<td>Quantidade de familias (aprox): </td>
        <td><input type="text" name="quantidade" placeholder="10"/></td>
    </tr>
    <tr>
    	<td>Tipos de doa&ccedil;&otilde;es: </td>
        <td><input type="text" name="doacao" placeholder="Alimentos nao pereciveis, roupas, moveis, etc..."/></td>
    </tr>
    <tr>
    	<td>Observa&ccedil;&otilde;es: </td>
        <td><input type="text" name="observacao" placeholder="Recomendamos falar com determinada pessoa para organizar as doacoes..."/></td>
    </tr>
</table>
<input type="submit" value="Cadastrar" id="submit"/>
</form>
</div>
</body>
</html>